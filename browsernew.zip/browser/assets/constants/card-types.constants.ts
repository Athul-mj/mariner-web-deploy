export const CardTypes = {
  CARD: 1,
  CASHBOX: 0
};

export enum FuelType {
  Liter = 1,
  Gallon = 2,
}