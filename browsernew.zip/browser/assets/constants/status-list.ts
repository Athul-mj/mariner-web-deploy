export enum Status {
    UNDERWAY = 'Underway',
    AT_ANCHOR = 'At Anchor',
    DRY_DOCK = 'Dry Dock',

}